# Broker

**Sorgenti:** `broker/broker.ino` (include `broker/index_html.h`, vedi [dashboard.md](dashboard.md))
**Scheda:** ESP32 generico (FQBN `esp32:esp32:esp32`). Nessun GPIO usato.
**Dipendenza:** PicoMQTT (broker MQTT; il core ESP32 non ne include uno).

## Responsabilita'
Broker MQTT sulla porta 1883, unico subscriber di `esp32/temperatura`, conserva lo storico e serve la dashboard.

## Rete
- `USE_ACCESS_POINT 1`: crea la rete `AP_SSID` / `AP_PASS`, IP fisso `192.168.4.1`.
- `USE_ACCESS_POINT 0` (attuale): si collega a `STA_SSID` / `STA_PASS` (`Auricle`), IP assegnato dal router (DHCP)
  e stampato sul Serial Monitor. L'IP puo' cambiare dopo un riavvio del router.
- In entrambe le modalita' si annuncia via mDNS come `MDNS_NAME.local` (`esp32-broker.local`) con i servizi
  `_mqtt._tcp` (1883) e `_http._tcp` (80). Il publisher usa questo nome, quindi l'IP non va mai copiato a mano.
  `MDNS_NAME` deve coincidere con `BROKER_NAME` del publisher.
- MQTT senza utente/password: chiunque sulla rete puo' pubblicare.

## Protocollo
- **MQTT** `esp32/temperatura`: payload testo ASCII con un numero (`"23.4"`). Payload non numerici scartati.
- **HTTP** `GET /` → dashboard.
- **HTTP** `GET /api/temp` → `{"temp":<float|null>,"age":<ms dall'ultimo campione>,"seq":<n>,"uptime":<s>}`
- **HTTP** `GET /api/history` → `{"now":<ms>,"seq":<n>,"data":[[<ms>,<float>],...]}`, dal piu' vecchio al piu' recente.

## Invarianti
- Storico circolare di `HIST_SIZE = 150` campioni (RAM fissa, nessuna allocazione per campione).
- `seq` cresce di 1 a ogni campione: la dashboard lo usa per non duplicare i punti.
- I tempi sono `millis()` del broker, non orario reale; dopo ~49 giorni `millis()` riparte da 0.

## Timing
- `loop()` non bloccante: `mqtt.loop()` + `web.handleClient()`.
- In modalita' router `setup()` attende il Wi-Fi **senza timeout**: con SSID/password sbagliati resta bloccato
  (sul Serial Monitor compaiono solo puntini).

## Validazione
```bash
"$CLI" compile -b esp32:esp32:esp32 broker
```
Smoke test: il Serial Monitor mostra `Connesso, IP: ...`, `Nome in rete: esp32-broker.local` e `Broker MQTT in ascolto`;
`http://esp32-broker.local/api/temp` risponde JSON.
