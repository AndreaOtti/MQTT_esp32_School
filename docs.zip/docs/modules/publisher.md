# Publisher

**Sorgenti:** `publisher/publisher.ino`
**Scheda:** ABrobot ESP32-C3 con OLED 0.42" (FQBN `esp32:esp32:esp32c3`, *USB CDC On Boot = Enabled*).

## Responsabilita'
Legge il sensore di temperatura interno del chip, lo pubblica sul broker e lo mostra sull'OLED.

## Pinout
| GPIO | Uso | Note |
|---|---|---|
| 8 | LED blu | attivo **basso**; spento (HIGH) al boot |
| 5 | OLED SDA | I2C hardware |
| 6 | OLED SCL | I2C hardware |

## Configurazione
- `WIFI_SSID` / `WIFI_PASS`: stessa rete del broker (ora `Auricle`). Non vengono mai stampati sul seriale.
- `BROKER_NAME`: nome mDNS del broker senza `.local` (`esp32-broker`), deve coincidere con `MDNS_NAME` del broker.
  L'IP viene risolto a runtime e assegnato a `mqtt.host`; finche' e' vuoto PicoMQTT non tenta la connessione.
- `USE_OLED`: `0` elimina display e dipendenza U8g2.
- MQTT: nessuna password (il broker non la richiede). Client id `abrobot-publisher`.

## Dipendenze
- **PicoMQTT**: client MQTT.
- **U8g2**: driver SSD1306 72x40 e font. Mantenuta perche' riscrivere driver e font richiederebbe piu' codice di
  quello che fa risparmiare; isolata dietro `USE_OLED` e usata solo in `showText()`.

## Protocollo
Pubblica su `esp32/temperatura` un testo con una cifra decimale (`String(t, 1)`), compatibile con il parser del broker.

## Timing
- Invio ogni `INTERVAL_MS = 2000` ms (se il broker non e' connesso il valore non viene inviato, il seriale stampa `NON inviato`).
- `findBroker()`: query mDNS bloccante fino a 2 s; all'avvio e poi ogni 10 s finche' MQTT non e' connesso
  (cosi' un nuovo IP del broker viene ritrovato).
- `readTemperature()`: media di 10 letture, ~20 ms bloccanti (il sensore interno e' rumoroso).
- Lampo LED: 30 ms bloccanti per invio.
- `connectWiFi()` attende **senza timeout** (LED lampeggia ogni 500 ms); viene richiamata anche in `loop()` se il Wi-Fi cade.
- Potenza TX fissata a 8.5 dBm: a piena potenza molte schede C3 con questa antenna non si connettono.

## Limiti noti
- Il sensore interno misura il chip, non l'ambiente (valori piu' alti della temperatura della stanza).

## Validazione
```bash
"$CLI" compile -b esp32:esp32:esp32c3:CDCOnBoot=cdc publisher
```
Smoke test: il seriale stampa `Broker trovato: <IP>`, il LED lampeggia e poi resta spento, l'OLED mostra la temperatura, il Serial Monitor stampa `Pubblicato ...`
ogni 2 s, il broker stampa `[MQTT] esp32/temperatura = ...`.
