# Dashboard

**Sorgenti:** `index.html` (sorgente di verita'), `broker/index_html.h` (generato, servito dal broker su `/`).

## Rigenerare `index_html.h`
Copiare il contenuto di `index.html` tra `R"rawliteral(` e `)rawliteral";`, mantenendo le righe di commento iniziali
e `#pragma once`. L'HTML non deve contenere la sequenza `)rawliteral"`.

## Comportamento
- All'avvio legge `/api/history`, poi interroga `/api/temp` ogni `CFG.poll = 1000` ms (contratto in [broker.md](broker.md)).
- Un punto nuovo viene aggiunto solo se `seq` e' cambiato.
- Stato *Publisher offline* se l'ultimo campione e' piu' vecchio di `CFG.offlineMs = 10000` ms.
- Scala del tachimetro `CFG.min..CFG.max` = 0..100 °C; grafico fino a `CFG.maxPoints = 900` punti.
- **Modalita' demo** con dati simulati: aprendo il file dal PC (`file://`) o aggiungendo `?demo` all'URL.

## Validazione
Aprire `index.html` dal PC (demo) e controllare tachimetro e grafico; dopo la copia in `index_html.h` ricompilare il broker.
