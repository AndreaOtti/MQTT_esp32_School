# Indice moduli

| Modulo | Sorgenti | Documento |
|---|---|---|
| Broker | `broker/broker.ino` | [modules/broker.md](modules/broker.md) |
| Dashboard | `index.html` (sorgente), `broker/index_html.h` (generato) | [modules/dashboard.md](modules/dashboard.md) |
| Publisher | `publisher/publisher.ino` | [modules/publisher.md](modules/publisher.md) |

Flusso dati: Publisher → (MQTT `esp32/temperatura`) → Broker → (HTTP `/api/*`) → Dashboard.
