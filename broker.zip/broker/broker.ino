/*
 * ESP32 #1 - BROKER MQTT + WEB APP
 *
 * - Si collega al router (o crea la rete "ESP32-Broker" se USE_ACCESS_POINT = 1)
 * - Si annuncia in rete via mDNS come "esp32-broker.local": il publisher lo
 *   trova da solo, senza dover conoscere l'IP
 * - Fa da broker MQTT sulla porta 1883 (qualsiasi client MQTT puo' collegarsi)
 * - Si iscrive al topic della temperatura e salva lo storico
 * - Serve la dashboard web su http://esp32-broker.local (o http://<IP del broker>)
 *
 * Libreria richiesta (Library Manager): "PicoMQTT" di Michal Lesniewski
 *
 * Documentazione: docs/modules/broker.md
 */

#include <WiFi.h>
#include <WebServer.h>
#include <ESPmDNS.h>
#include <PicoMQTT.h>
#include "index_html.h"

// ---------- Configurazione ----------
#define USE_ACCESS_POINT 0            // 1 = crea la propria rete, 0 = si collega al router

const char* AP_SSID   = "ESP32-Broker";
const char* AP_PASS   = "12345678";   // minimo 8 caratteri

const char* STA_SSID  = "Auricle";  // usati solo se USE_ACCESS_POINT = 0
const char* STA_PASS  = "12356789";

const char* MDNS_NAME  = "esp32-broker";   // nome in rete: esp32-broker.local
const char* TOPIC_TEMP = "esp32/temperatura";
// ------------------------------------

PicoMQTT::Server mqtt;      // porta 1883
WebServer web(80);

// Storico circolare dei campioni
const int HIST_SIZE = 150;
struct Sample { uint32_t ms; float v; };
Sample hist[HIST_SIZE];
int histHead = 0, histCount = 0;
uint32_t seq = 0;

float lastTemp = NAN;
uint32_t lastUpdate = 0;

void addSample(float v) {
  hist[histHead] = { millis(), v };
  histHead = (histHead + 1) % HIST_SIZE;
  if (histCount < HIST_SIZE) histCount++;
  seq++;
  lastTemp = v;
  lastUpdate = millis();
}

void handleTemp() {
  String json = "{\"temp\":";
  json += isnan(lastTemp) ? String("null") : String(lastTemp, 2);
  json += ",\"age\":" + String(lastUpdate ? millis() - lastUpdate : 0);
  json += ",\"seq\":" + String(seq);
  json += ",\"uptime\":" + String(millis() / 1000);
  json += "}";
  web.send(200, "application/json", json);
}

void handleHistory() {
  String json = "{\"now\":" + String(millis()) + ",\"seq\":" + String(seq) + ",\"data\":[";
  int start = (histHead - histCount + HIST_SIZE) % HIST_SIZE;
  for (int i = 0; i < histCount; i++) {
    const Sample& s = hist[(start + i) % HIST_SIZE];
    if (i) json += ',';
    json += '[' + String(s.ms) + ',' + String(s.v, 2) + ']';
  }
  json += "]}";
  web.send(200, "application/json", json);
}

void setup() {
  Serial.begin(115200);

#if USE_ACCESS_POINT
  WiFi.mode(WIFI_AP);
  WiFi.softAP(AP_SSID, AP_PASS);
  Serial.printf("\nAccess Point \"%s\" attivo, IP: %s\n", AP_SSID, WiFi.softAPIP().toString().c_str());
#else
  WiFi.mode(WIFI_STA);
  WiFi.begin(STA_SSID, STA_PASS);
  Serial.print("\nConnessione al Wi-Fi");
  while (WiFi.status() != WL_CONNECTED) { delay(500); Serial.print('.'); }
  Serial.printf("\nConnesso, IP: %s\n", WiFi.localIP().toString().c_str());
#endif

  MDNS.begin(MDNS_NAME);
  MDNS.addService("mqtt", "tcp", 1883);
  MDNS.addService("http", "tcp", 80);
  Serial.printf("Nome in rete: %s.local\n", MDNS_NAME);

  // Il broker stesso si iscrive al topic della temperatura
  mqtt.subscribe(TOPIC_TEMP, [](const char* topic, const char* payload) {
    char* end;
    float v = strtof(payload, &end);
    if (end == payload) return;   // payload non numerico
    addSample(v);
    Serial.printf("[MQTT] %s = %.2f\n", topic, v);
  });
  mqtt.begin();
  Serial.println("Broker MQTT in ascolto sulla porta 1883");

  web.on("/", []() { web.send(200, "text/html", INDEX_HTML); });
  web.on("/api/temp", handleTemp);
  web.on("/api/history", handleHistory);
  web.begin();
  Serial.printf("Dashboard: http://%s.local\n", MDNS_NAME);
}

void loop() {
  mqtt.loop();
  web.handleClient();
}
