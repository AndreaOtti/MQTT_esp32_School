// GENERATO da ../index.html (sorgente): non modificare qui, ricopia index.html
// dentro R"rawliteral(...)rawliteral". Documentazione: docs/modules/dashboard.md
#pragma once
const char INDEX_HTML[] PROGMEM = R"rawliteral(<!DOCTYPE html>
<!-- Dashboard: docs/modules/dashboard.md. Dopo ogni modifica ricopiare in broker/index_html.h -->
<html lang="it">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>ESP32 Temperatura</title>
<style>
:root{--bg:#0b1220;--card:#141d2f;--card2:#1b2742;--line:#24314f;--text:#e8eefc;--muted:#8a97b5;
--accent:#23c48e;--warn:#f5a623;--hot:#ff4d5e;--cold:#3fa9f5}
*{box-sizing:border-box;margin:0;padding:0}
body{background:var(--bg);color:var(--text);font-family:-apple-system,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;min-height:100vh}
header{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:14px 20px;background:var(--card);border-bottom:1px solid var(--line);position:sticky;top:0;z-index:2}
.brand{display:flex;align-items:center;gap:12px;min-width:0}
.logo{width:38px;height:38px;border-radius:11px;background:var(--accent);display:grid;place-items:center;flex:none}
.title{font-weight:700;font-size:17px}
.sub{font-size:12px;color:var(--muted)}
.status{display:flex;align-items:center;gap:8px;font-size:13px;padding:7px 13px;border-radius:999px;background:var(--card2);white-space:nowrap}
.dot{width:9px;height:9px;border-radius:50%;background:var(--muted)}
.on .dot{background:var(--accent);animation:pulse 2s infinite}
.stale .dot{background:var(--warn)}
.off .dot{background:var(--hot)}
@keyframes pulse{0%{box-shadow:0 0 0 0 rgba(35,196,142,.6)}70%{box-shadow:0 0 0 8px rgba(35,196,142,0)}100%{box-shadow:0 0 0 0 rgba(35,196,142,0)}}
main{max-width:1100px;margin:0 auto;padding:20px 16px 40px;display:grid;gap:16px;grid-template-columns:repeat(12,1fr)}
.w{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:16px 18px}
.w h3{font-size:11px;font-weight:600;letter-spacing:.09em;text-transform:uppercase;color:var(--muted);margin-bottom:12px;display:flex;justify-content:space-between;align-items:center;gap:8px}
.gauge{grid-column:span 7;display:flex;flex-direction:column}
.gauge svg{width:100%;max-width:440px;margin:auto;display:block}
.side{grid-column:span 5;display:flex;flex-direction:column;gap:16px}
.chart{grid-column:span 12}
@media(max-width:820px){.gauge,.side,.chart{grid-column:span 12}}
/* gauge */
.track{fill:none;stroke:var(--card2);stroke-width:14;stroke-linecap:round}
.val{fill:none;stroke-width:14;stroke-linecap:round;stroke-dasharray:100 100;stroke-dashoffset:100;transition:stroke-dashoffset .8s ease,stroke .8s}
.zone{fill:none;stroke-width:3;opacity:.9}
.tk{stroke:#4a5878;stroke-width:1.5}
.tk.M{stroke:#9aa7c4;stroke-width:2.2}
.lbl{fill:var(--muted);font-size:11px;text-anchor:middle}
#needle{transform-box:view-box;transform-origin:150px 145px;transform:rotate(-135deg);transition:transform .8s cubic-bezier(.3,1.4,.5,1)}
#needle path{fill:var(--text)}
.hub{fill:var(--card)}
.gv{fill:var(--text);font-size:34px;font-weight:700;text-anchor:middle}
.gu{fill:var(--muted);font-size:13px;text-anchor:middle}
/* value */
.big{display:flex;align-items:baseline;gap:8px}
.big b{font-size:54px;font-weight:700;line-height:1;transition:color .8s}
.big span{font-size:20px;color:var(--muted)}
.trend{margin-top:8px;font-size:13px;color:var(--muted)}
.stats{display:grid;grid-template-columns:1fr 1fr;gap:10px}
.st{background:var(--card2);border-radius:12px;padding:10px 12px}
.st small{display:block;font-size:11px;color:var(--muted);margin-bottom:4px}
.st b{font-size:20px;font-weight:600}
.info{font-size:13px;line-height:1.9}
.info div{display:flex;justify-content:space-between;gap:10px;border-bottom:1px dashed var(--line)}
.info div:last-child{border:0}
.info span{color:var(--muted)}
.info code{font-family:ui-monospace,Consolas,monospace;font-size:12px}
/* chart */
.seg{display:flex;background:var(--card2);border-radius:9px;padding:3px}
.seg button{background:none;border:0;color:var(--muted);font-family:inherit;font-size:11px;font-weight:600;padding:5px 10px;border-radius:7px;cursor:pointer;letter-spacing:0;text-transform:none}
.seg button.a{background:var(--accent);color:#06281c}
#cv{width:100%;height:260px;display:block;touch-action:pan-y}
</style>
</head>
<body>
<header>
  <div class="brand">
    <div class="logo"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#06281c" stroke-width="2.4" stroke-linecap="round"><path d="M14 14.8V4a2 2 0 1 0-4 0v10.8a4 4 0 1 0 4 0z"/></svg></div>
    <div><div class="title">ESP32 Temperatura</div><div class="sub" id="sub">MQTT · esp32/temperatura</div></div>
  </div>
  <div class="status off" id="status"><i class="dot"></i><span id="stxt">Connessione…</span></div>
</header>

<main>
  <section class="w gauge">
    <h3>Tachimetro</h3>
    <svg viewBox="0 0 300 245" id="gauge">
      <g id="scale"></g>
      <g id="needle"><path d="M146.5 145 L150 58 L153.5 145 Z"/></g>
      <circle cx="150" cy="145" r="11" fill="var(--text)"/>
      <circle cx="150" cy="145" r="5" class="hub"/>
      <text x="150" y="212" class="gv" id="gv">--</text>
      <text x="150" y="232" class="gu">°C</text>
    </svg>
  </section>

  <div class="side">
    <section class="w">
      <h3>Temperatura attuale</h3>
      <div class="big"><b id="big">--</b><span>°C</span></div>
      <div class="trend" id="trend">In attesa del publisher…</div>
    </section>
    <section class="w">
      <h3>Statistiche <span id="srange">1 min</span></h3>
      <div class="stats">
        <div class="st"><small>Minima</small><b id="smin">--</b></div>
        <div class="st"><small>Massima</small><b id="smax">--</b></div>
        <div class="st"><small>Media</small><b id="savg">--</b></div>
        <div class="st"><small>Campioni</small><b id="scnt">0</b></div>
      </div>
    </section>
    <section class="w info">
      <h3>Connessione</h3>
      <div><span>Broker MQTT</span><code id="ibroker">-</code></div>
      <div><span>Topic</span><code>esp32/temperatura</code></div>
      <div><span>Ultimo dato</span><code id="iage">-</code></div>
      <div><span>Uptime broker</span><code id="iup">-</code></div>
    </section>
  </div>

  <section class="w chart">
    <h3>Storico
      <div class="seg" id="seg">
        <button data-r="60000" class="a">1 min</button><button data-r="300000">5 min</button><button data-r="900000">15 min</button><button data-r="0">Tutto</button>
      </div>
    </h3>
    <canvas id="cv"></canvas>
  </section>
</main>

<script>
const CFG={min:0,max:100,poll:1000,offlineMs:10000,maxPoints:900};
const $=id=>document.getElementById(id);
const DEMO=location.protocol==='file:'||/demo/.test(location.search);
const C={cold:'#3fa9f5',ok:'#23c48e',warn:'#f5a623',hot:'#ff4d5e'};
const ZONES=[[0,30,C.cold],[30,60,C.ok],[60,80,C.warn],[80,100,C.hot]];
const col=v=>v<30?C.cold:v<60?C.ok:v<80?C.warn:C.hot;

let pts=[],lastSeq=-1,range=60000,lastData=0,brokerOk=false,uptime=null,hoverX=null;

/* ---------- Gauge ---------- */
const NS='http://www.w3.org/2000/svg',G={cx:150,cy:145,r:115};
const polar=(r,a)=>{const t=a*Math.PI/180;return[G.cx+r*Math.sin(t),G.cy-r*Math.cos(t)]};
const arc=(r,a0,a1)=>{const[x0,y0]=polar(r,a0),[x1,y1]=polar(r,a1);return`M${x0} ${y0}A${r} ${r} 0 ${a1-a0>180?1:0} 1 ${x1} ${y1}`};
const v2a=v=>-135+270*(Math.min(Math.max(v,CFG.min),CFG.max)-CFG.min)/(CFG.max-CFG.min);
function el(tag,attrs,parent){const e=document.createElementNS(NS,tag);for(const k in attrs)e.setAttribute(k,attrs[k]);parent.appendChild(e);return e}
let valArc;
(function buildGauge(){
  const g=$('scale');
  el('path',{d:arc(G.r,-135,135),class:'track'},g);
  valArc=el('path',{d:arc(G.r,-135,135),class:'val',pathLength:100},g);
  ZONES.forEach(z=>el('path',{d:arc(101,v2a(z[0]),v2a(z[1])),stroke:z[2],class:'zone'},g));
  for(let v=CFG.min;v<=CFG.max;v+=5){
    const M=v%10===0,a=v2a(v),[x0,y0]=polar(97,a),[x1,y1]=polar(M?85:91,a);
    el('line',{x1:x0,y1:y0,x2:x1,y2:y1,class:M?'tk M':'tk'},g);
    if(M){const[lx,ly]=polar(72,a);el('text',{x:lx,y:ly+4,class:'lbl'},g).textContent=v}
  }
})();

/* ---------- Dati ---------- */
function add(t,v){pts.push({t,v});if(pts.length>CFG.maxPoints)pts.shift();lastData=t;render()}
const visible=()=>{const now=Date.now();return range?pts.filter(p=>p.t>=now-range):pts};
const fmt=v=>v==null?'--':v.toFixed(1);
const fmtAge=ms=>ms<1000?'adesso':ms<60000?Math.round(ms/1000)+' s fa':Math.round(ms/60000)+' min fa';
const fmtUp=s=>{const h=Math.floor(s/3600),m=Math.floor(s%3600/60);return h?`${h}h ${m}m`:`${m}m ${s%60}s`};

function render(){
  const last=pts[pts.length-1];
  if(last){
    const v=last.v,a=v2a(v);
    valArc.style.strokeDashoffset=100-(a+135)/270*100;
    valArc.style.stroke=col(v);
    $('needle').style.transform=`rotate(${a}deg)`;
    $('gv').textContent=fmt(v);
    $('big').textContent=fmt(v);$('big').style.color=col(v);
    const prev=pts[pts.length-2];
    if(prev){const d=v-prev.v;$('trend').textContent=(d>0.05?'▲ +':d<-0.05?'▼ ':'● ')+d.toFixed(1)+' °C rispetto al campione precedente'}
  }
  const vis=visible(),vals=vis.map(p=>p.v);
  $('smin').textContent=vals.length?fmt(Math.min(...vals)):'--';
  $('smax').textContent=vals.length?fmt(Math.max(...vals)):'--';
  $('savg').textContent=vals.length?fmt(vals.reduce((a,b)=>a+b,0)/vals.length):'--';
  $('scnt').textContent=vals.length;
  drawChart(vis);
}

function updStatus(){
  const age=lastData?Date.now()-lastData:null,s=$('status');
  if(!brokerOk){s.className='status off';$('stxt').textContent='Broker non raggiungibile'}
  else if(age==null||age>CFG.offlineMs){s.className='status stale';$('stxt').textContent='Publisher offline'}
  else{s.className='status on';$('stxt').textContent=DEMO?'Demo':'Online'}
  $('iage').textContent=age==null?'-':fmtAge(age);
  $('iup').textContent=uptime==null?'-':fmtUp(uptime);
}

async function loadHistory(){
  try{
    const j=await(await fetch('/api/history',{cache:'no-store'})).json(),now=Date.now();
    pts=j.data.map(d=>({t:now-(j.now-d[0]),v:d[1]}));
    lastSeq=j.seq;if(pts.length)lastData=pts[pts.length-1].t;brokerOk=true;
  }catch(e){}
  render();
}
async function poll(){
  try{
    const j=await(await fetch('/api/temp',{cache:'no-store'})).json();
    brokerOk=true;uptime=j.uptime;
    if(j.temp!==null&&j.seq!==lastSeq){lastSeq=j.seq;add(Date.now()-j.age,j.temp)}
  }catch(e){brokerOk=false}
  updStatus();setTimeout(poll,CFG.poll);
}

/* ---------- Grafico ---------- */
const cv=$('cv'),ctx=cv.getContext('2d');
function drawChart(data){
  data=data||visible();
  const dpr=window.devicePixelRatio||1,W=cv.clientWidth,H=cv.clientHeight;
  if(cv.width!==Math.round(W*dpr)||cv.height!==Math.round(H*dpr)){cv.width=Math.round(W*dpr);cv.height=Math.round(H*dpr)}
  ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,W,H);
  ctx.font='11px -apple-system,Segoe UI,Roboto,sans-serif';ctx.fillStyle='#8a97b5';
  if(data.length<2){ctx.textAlign='center';ctx.fillText('In attesa di dati…',W/2,H/2);return}
  const L=40,R=12,T=10,B=24,w=W-L-R,h=H-T-B,now=Date.now();
  let lo=Math.min(...data.map(p=>p.v)),hi=Math.max(...data.map(p=>p.v));
  if(hi-lo<2){const m=(hi+lo)/2;lo=m-1;hi=m+1}
  const pad=(hi-lo)*.15;lo-=pad;hi+=pad;
  const t0=range?now-range:data[0].t,t1=range?now:data[data.length-1].t;
  const X=t=>L+(t-t0)/((t1-t0)||1)*w,Y=v=>T+(hi-v)/(hi-lo)*h;
  // griglia
  ctx.strokeStyle='#24314f';ctx.lineWidth=1;ctx.textAlign='right';ctx.textBaseline='middle';
  for(let i=0;i<=4;i++){const y=T+h*i/4;ctx.beginPath();ctx.moveTo(L,y);ctx.lineTo(W-R,y);ctx.stroke();ctx.fillText((hi-(hi-lo)*i/4).toFixed(1),L-8,y)}
  ctx.textBaseline='alphabetic';
  for(let i=0;i<=3;i++){const t=t0+(t1-t0)*i/3;ctx.textAlign=i===0?'left':i===3?'right':'center';
    ctx.fillText(new Date(t).toLocaleTimeString('it-IT',{hour:'2-digit',minute:'2-digit',second:'2-digit'}),X(t),H-6)}
  // area + linea
  ctx.save();ctx.beginPath();ctx.rect(L,T-4,w,h+8);ctx.clip();
  const gr=ctx.createLinearGradient(0,T,0,T+h);gr.addColorStop(0,'rgba(35,196,142,.35)');gr.addColorStop(1,'rgba(35,196,142,0)');
  ctx.beginPath();data.forEach((p,i)=>i?ctx.lineTo(X(p.t),Y(p.v)):ctx.moveTo(X(p.t),Y(p.v)));
  ctx.strokeStyle='#23c48e';ctx.lineWidth=2.2;ctx.lineJoin='round';ctx.stroke();
  ctx.lineTo(X(data[data.length-1].t),T+h);ctx.lineTo(X(data[0].t),T+h);ctx.closePath();ctx.fillStyle=gr;ctx.fill();
  ctx.restore();
  const lp=data[data.length-1];dot(X(lp.t),Y(lp.v),'#23c48e');
  // tooltip
  if(hoverX!=null&&hoverX>=L&&hoverX<=W-R){
    let p=data[0];for(const q of data)if(Math.abs(X(q.t)-hoverX)<Math.abs(X(p.t)-hoverX))p=q;
    const x=X(p.t),y=Y(p.v);
    ctx.strokeStyle='rgba(232,238,252,.25)';ctx.setLineDash([4,4]);ctx.beginPath();ctx.moveTo(x,T);ctx.lineTo(x,T+h);ctx.stroke();ctx.setLineDash([]);
    dot(x,y,col(p.v));
    const txt=p.v.toFixed(1)+' °C  ·  '+new Date(p.t).toLocaleTimeString('it-IT');
    ctx.font='600 12px -apple-system,Segoe UI,Roboto,sans-serif';const tw=ctx.measureText(txt).width+16;
    const bx=Math.min(Math.max(x-tw/2,L),W-R-tw),by=Math.max(y-38,T);
    ctx.fillStyle='#1b2742';ctx.beginPath();ctx.roundRect?ctx.roundRect(bx,by,tw,26,7):ctx.rect(bx,by,tw,26);ctx.fill();
    ctx.fillStyle='#e8eefc';ctx.textAlign='left';ctx.textBaseline='middle';ctx.fillText(txt,bx+8,by+13);
  }
}
function dot(x,y,c){ctx.beginPath();ctx.arc(x,y,4.5,0,7);ctx.fillStyle=c;ctx.fill();ctx.lineWidth=2;ctx.strokeStyle='#141d2f';ctx.stroke()}

const setHover=x=>{hoverX=x;drawChart()};
cv.addEventListener('mousemove',e=>setHover(e.offsetX));
cv.addEventListener('mouseleave',()=>setHover(null));
cv.addEventListener('touchmove',e=>{const r=cv.getBoundingClientRect();setHover(e.touches[0].clientX-r.left)},{passive:true});
cv.addEventListener('touchend',()=>setHover(null));
window.addEventListener('resize',()=>drawChart());

$('seg').addEventListener('click',e=>{
  const b=e.target.closest('button');if(!b)return;
  document.querySelectorAll('#seg button').forEach(x=>x.classList.toggle('a',x===b));
  range=+b.dataset.r;$('srange').textContent=b.textContent;render();
});

/* ---------- Avvio ---------- */
$('ibroker').textContent=(location.hostname||'192.168.4.1')+':1883';
setInterval(()=>{updStatus();drawChart()},1000);
if(DEMO){
  // Modalita' demo: apri il file direttamente dal PC per vedere la grafica senza ESP32
  $('sub').textContent='Modalità demo · dati simulati';brokerOk=true;uptime=0;
  let v=45;const now=Date.now();
  for(let i=90;i>0;i--){v+=(Math.random()-.5)*1.2;pts.push({t:now-i*2000,v})}
  lastData=now;render();updStatus();
  setInterval(()=>{v=Math.min(95,Math.max(20,v+(Math.random()-.48)*1.6));uptime+=2;add(Date.now(),+v.toFixed(1));updStatus()},2000);
}else{loadHistory().then(poll)}
</script>
</body>
</html>
)rawliteral";
