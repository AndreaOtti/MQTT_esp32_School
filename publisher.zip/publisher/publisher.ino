/*
 * ABROBOT ESP32-C3 (con display OLED 0.42") - PUBLISHER
 *
 * Si collega alla rete del broker e pubblica periodicamente la propria
 * temperatura interna (sensore del chip) sul topic "esp32/temperatura".
 * Il broker viene trovato via mDNS ("esp32-broker.local"): non serve il suo IP.
 * La temperatura viene mostrata anche sul display OLED 72x40 della scheda.
 *
 * Librerie richieste (Library Manager):
 *   - "PicoMQTT" di Michal Lesniewski
 *   - "U8g2" di olikraus (solo se USE_OLED = 1)
 *
 * Arduino IDE: scheda "ESP32C3 Dev Module", "USB CDC On Boot" = Enabled
 * (altrimenti il Serial Monitor non mostra nulla)
 *
 * Documentazione: docs/modules/publisher.md
 */

#include <WiFi.h>
#include <ESPmDNS.h>
#include <PicoMQTT.h>

// ---------- Configurazione ----------
#define USE_OLED 1                          // 1 = usa il display della scheda, 0 = no

const char* WIFI_SSID   = "Auricle";        // stessa rete del broker (STA_SSID, o AP_SSID se USE_ACCESS_POINT = 1)
const char* WIFI_PASS   = "12356789";
const char* BROKER_NAME = "esp32-broker";   // = MDNS_NAME del broker, senza ".local"
const char* TOPIC_TEMP  = "esp32/temperatura";
const uint32_t INTERVAL_MS = 2000;          // ogni quanto pubblicare

const int LED_PIN = 8;                      // LED blu della scheda (acceso con LOW)
const int OLED_SDA = 5;
const int OLED_SCL = 6;
// ------------------------------------

#if USE_OLED
#include <U8g2lib.h>
U8G2_SSD1306_72X40_ER_F_HW_I2C oled(U8G2_R0, U8X8_PIN_NONE, OLED_SCL, OLED_SDA);
#endif

// Host vuoto finche' il broker non e' stato trovato: PicoMQTT non tenta la connessione
PicoMQTT::Client mqtt(nullptr, 1883, "abrobot-publisher");
uint32_t lastPublish = 0;
uint32_t lastLookup = 0;

void showText(const char* line1, const char* line2) {
#if USE_OLED
  oled.clearBuffer();
  oled.setFont(u8g2_font_6x10_tf);
  oled.drawStr(0, 10, line1);
  oled.setFont(u8g2_font_logisoso16_tf);
  oled.drawStr(0, 38, line2);
  oled.sendBuffer();
#endif
}

// Media di piu' letture: il sensore interno e' piuttosto rumoroso
float readTemperature() {
  float sum = 0;
  for (int i = 0; i < 10; i++) { sum += temperatureRead(); delay(2); }
  return sum / 10;
}

void connectWiFi() {
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  // L'antenna di queste schede C3 e' debole: con la potenza massima
  // spesso non si connettono, a 8.5 dBm invece funzionano
  WiFi.setTxPower(WIFI_POWER_8_5dBm);
  Serial.print("Connessione a ");
  Serial.print(WIFI_SSID);
  showText("WiFi...", WIFI_SSID);
  while (WiFi.status() != WL_CONNECTED) {
    digitalWrite(LED_PIN, !digitalRead(LED_PIN));   // lampeggia mentre si connette
    delay(500);
    Serial.print('.');
  }
  digitalWrite(LED_PIN, HIGH);
  Serial.printf("\nConnesso, IP: %s\n", WiFi.localIP().toString().c_str());
}

// Cerca l'IP del broker via mDNS (blocca fino a 2 s). Richiamata finche' MQTT non e'
// connesso, cosi' se il router assegna al broker un IP nuovo il publisher lo ritrova.
void findBroker() {
  lastLookup = millis();
  IPAddress ip = MDNS.queryHost(BROKER_NAME);
  if (ip == IPAddress()) {
    Serial.printf("Broker %s.local non trovato\n", BROKER_NAME);
    showText("Cerco", "broker");
    return;
  }
  if (mqtt.host != ip.toString()) {
    mqtt.host = ip.toString();
    Serial.printf("Broker trovato: %s\n", mqtt.host.c_str());
  }
}

void setup() {
  Serial.begin(115200);
  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, HIGH);
#if USE_OLED
  oled.begin();
#endif
  connectWiFi();
  MDNS.begin("abrobot-publisher");
  findBroker();
  mqtt.begin();   // si riconnette da solo al broker se la connessione cade
}

void loop() {
  if (WiFi.status() != WL_CONNECTED) connectWiFi();
  if (!mqtt.connected() && millis() - lastLookup >= 10000) findBroker();
  mqtt.loop();

  if (millis() - lastPublish >= INTERVAL_MS) {
    lastPublish = millis();
    float t = readTemperature();
    bool ok = mqtt.publish(TOPIC_TEMP, String(t, 1));
    Serial.printf("%s %s = %.1f C\n", ok ? "Pubblicato" : "NON inviato (broker non connesso)", TOPIC_TEMP, t);

    char buf[12];
    snprintf(buf, sizeof(buf), "%.1f C", t);
    showText("Temperatura", buf);

    digitalWrite(LED_PIN, LOW);     // breve lampo a ogni invio
    delay(30);
    digitalWrite(LED_PIN, HIGH);
  }
}
